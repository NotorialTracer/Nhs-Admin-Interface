export PATH=${PATH}:/usr/local/mysql-9.2.0-macos15-arm64/bin
